﻿# Legend

 - 📦 Boxing
 - 🔍 Reflection
 - 🤸 Flexability
 - ⏱️ Perfomance
 - 🛠️ Maintainability
 - 🛠️ Maintainability
 - ✔️ Good
 - ❌ Bad

# NAME

SUMMARY

## Result

TABLE

### First

INFO

| Aspect                   |Level   |
| ------------------------ |------- |
| 📦 Boxing                |✔️ No |
| 🔍 Reflection            |✔️ None |
| 🤸 Flexability (Generic) |❌ None  |
| ⏱️ Perfomance            |✔️ High  |
| 🛠️ Maintainability       |✔️ High  |

#### Benchmark Code

```csharp
int value = Subject.Value;
```

### First

INFO

| Aspect                   |Level   |
| ------------------------ |------- |
| 📦 Boxing                |✔️ No |
| 🔍 Reflection            |✔️ None |
| 🤸 Flexability (Generic) |❌ None  |
| ⏱️ Perfomance            |✔️ High  |
| 🛠️ Maintainability       |✔️ High  |

#### Benchmark Code

```csharp
int value = Subject.Value;
```
